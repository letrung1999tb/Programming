﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace studentmanagement
{
    class product
    {
        public string pname { get; set; }
        public string pid { get; set; }
        public int pcontact { get; set; }
        public product(string name, string id, int contact)
        {
            pname = name;
            pid = id;
            pcontact = contact;
        

        }
        public override string ToString()
        {
            return pname + " " + pid + " " + pcontact;
            return base.ToString();
        }

    }
}
