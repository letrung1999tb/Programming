﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace studentmanagement
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            string name = txtname.Text;
            string id = txtid.Text;
            int contact = Convert.ToInt32(txtcontact.Text);
            product p = new product(name, id, contact);
            lxbproduct.Items.Add(p);

        }

        private void btnremove_Click(object sender, EventArgs e)
        {
            product p = (product)lxbproduct.SelectedItem;
            if(p != null)
            {
                lxbproduct.Items.Remove(p);

            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            //1.add after remove
            string name = txtname.Text;
            string id = txtid.Text;
            int contact = Convert.ToInt32(txtcontact.Text);
            product p = new product(name, id, contact);
            lxbproduct.Items.Add(p);

            //2.remove
            product p1 = (product)lxbproduct.SelectedItem;
            if (p1 != null)
            {
                lxbproduct.Items.Remove(p1);

            }
        }
    }
}
